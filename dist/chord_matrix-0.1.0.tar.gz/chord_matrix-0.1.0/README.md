# chord_matrix

A package to generate a matrix for chord diagrams from TSV data files.

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install chord_matrix.

```bash
pip install git+https://github.com/Habibnasir23/chord_matrix.git


## Usage
chord_matrix --path /path/to/data.tsv --outputPath /path/to/output.tsv

